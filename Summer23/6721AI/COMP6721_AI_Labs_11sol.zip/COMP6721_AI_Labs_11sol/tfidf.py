#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.metrics.pairwise import cosine_similarity

corpus = np.array([
        'cheap meds for sale',
        'click here for the best meds',
        'book your trip',
        'cheap book sale, not meds',
        'here is the book for you'
])

# Create count vectors
vectorizer = CountVectorizer()
X = vectorizer.fit_transform(corpus)
print(vectorizer.get_feature_names())
print(X.toarray())

# create tf-idf vectors
tfidf_transformer = TfidfTransformer(sublinear_tf=True, use_idf=True)
tfidf_vectors = tfidf_transformer.fit_transform(X)
print(tfidf_vectors.toarray())

# print idf values
df_idf = pd.DataFrame(tfidf_transformer.idf_, index=vectorizer.get_feature_names(),columns=["idf_weights"])
print(df_idf.sort_values(by=['idf_weights']))

print(pd.DataFrame(tfidf_transformer.idf_, 
                   index=vectorizer.get_feature_names(),
                   columns=["idf_weights"]))

# compute cosine similarity
similarity_scores = cosine_similarity(tfidf_vectors)
print(similarity_scores)