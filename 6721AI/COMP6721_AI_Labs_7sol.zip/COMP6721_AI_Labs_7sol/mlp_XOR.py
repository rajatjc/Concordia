import numpy as np
from sklearn.neural_network import MLPClassifier

dataset = np.array([[1, 1, 0], [0, 1, 1], [1, 0, 1], [0, 0, 0]])
X = dataset[:, 0:2]
y = dataset[:, 2]
mlp = MLPClassifier(hidden_layer_sizes=(1,), activation='logistic')
mlp.fit(X, y)
