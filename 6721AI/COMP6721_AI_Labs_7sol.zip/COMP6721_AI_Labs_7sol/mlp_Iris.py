from sklearn.neural_network import MLPClassifier
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score, recall_score

iris = load_iris()
# features matrix
X = iris.data
# label vector
y = iris.target

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.30, random_state=1)

mlp = MLPClassifier(hidden_layer_sizes=(4,), max_iter=10000, random_state=1)
mlp.fit(X_train, y_train)

y_pred = mlp.predict(X_test)
print('Accuracy: %.2f' % accuracy_score(y_test, y_pred))

pre_macro = precision_score(y_test, y_pred, average='macro')
pre_micro = precision_score(y_test, y_pred, average='micro')

recall_macro = recall_score(y_test, y_pred, average='macro')
recall_micro = recall_score(y_test, y_pred, average='micro')

print("done!")
