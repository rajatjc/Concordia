import numpy as np
from sklearn.linear_model import Perceptron

dataset = np.array(
    [[1, 1, 0, 1, 0], [1, 1, 1, 0, 1], [0, 0, 1, 0, 0], [0, 1, 0, 1, 0], [1, 0, 1, 1, 1], [0, 1, 1, 1, 0], ])
X = dataset[:, 0:4]
y = dataset[:, 4]
perceptron_classifier = Perceptron(max_iter=40, eta0=0.1, random_state=1)
perceptron_classifier.fit(X, y)