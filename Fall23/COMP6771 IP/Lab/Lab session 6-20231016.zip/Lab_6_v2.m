clc
clear all
close all
%% step_1
X = imread('peppers.png');
X = rgb2gray(X);
X = im2double(X);
figure
subplot(241)
imshow(X)
%% step_2
Y1 = zeros(2*size(X));
Y1(1:size(X,1),1:size(X,2)) = X;
subplot(242)
imshow(Y1)
%% step_3
q11 = 0:size(Y1,2)-1;
q22 = 0:size(Y1,1)-1;
q11 = repmat(q11,size(Y1,1),1);%column
q22 = repmat(q22',1,size(Y1,2));%rows
q3 = q11+q22;
Y2 = Y1.*((-1).^q3);
subplot(243)
imshow(Y2)
%% step_4
Y3 = fft2(Y2);
subplot(244)
imagesc(log(abs(Y3)));colormap('gray')
%% step_5
[c1 , c2] = size(X);
r = 100;
q4 = (q22-c1).^2+(q11-c2).^2; 
q4 = q4 > (r^2);
Y4 = q4.*Y3;
subplot(248)
imagesc(log(abs(Y4)));colormap('gray')
%% step_6
Y5 = ifft2(Y4);
subplot(247)
imagesc(Y5);colormap('gray')
%% step_7
Y6 = Y5.*((-1).^q3);
subplot(246)
imagesc(Y6);colormap('gray')
%% step_8
Y7 = Y6(1:size(X,1),1:size(X,2));
subplot(245)
imagesc(Y7);colormap('gray')