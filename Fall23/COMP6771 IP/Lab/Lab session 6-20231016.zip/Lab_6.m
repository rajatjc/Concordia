clc 
clear all
close all
%% step1
I1 = imread('camera.bmp');
figure
imshow(I1)
%% step2
I2 = I1;
I2(end+1:2*end,end+1:2*end)=0;
figure
imshow(I2)
%% step3
x = 0:511;
y = 0:511;
[Y,X] = meshgrid(x,y);
% z = (-1).^(X+Y);
% I3 = z.*double(I2);
%% step4
I4 = fftshift(fft2(double(I2)));
figure
imagesc(log(abs(I4)))
colormap('gray')
%% step5
D = sqrt((X-256).^2+(Y-256).^2);
H = 1-exp((-D.^2)/(2*1024));
figure
imagesc(H)
colormap('gray')
%% step6
I6 = I4.*H;
%% step7
I7 = abs(ifft2(fftshift(I6)));
%% step8
I9 = I7(1:256,1:256);
figure
imagesc(I9)
colormap('gray')