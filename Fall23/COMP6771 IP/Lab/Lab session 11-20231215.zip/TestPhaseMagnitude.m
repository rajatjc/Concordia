function TestPhaseMagnitude

I = im2double(imread('lena512.bmp'));

img_fft = fftshift(fft2(I));

magnitude = sqrt(real(img_fft)^2 + imag(img_fft)^2);

phase = angle(img_fft);

I1 = abs(ifft2(ifftshift(magnitude)));
I2 = ifft2(ifftshift(exp(phase*1i)));

I1 = real(I1);
I2 = real(I2);

subplot(1,3,1); imshow(I); title('Original image');
subplot(1,3,2); imshow(I1); title('Magnitude only');
subplot(1,3,3); imshow(I2,[min(I2(:)), max(I2(:))]); title('Phase only');