/**
 *	Map class that is created by the TextFileReader
 */
public class Map {

}
