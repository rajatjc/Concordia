/**
 *	Map type created by the JSONFileReader
 */
public class OtherMap {

}
