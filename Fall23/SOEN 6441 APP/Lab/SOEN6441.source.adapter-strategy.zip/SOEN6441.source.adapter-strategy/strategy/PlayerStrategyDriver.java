import java.util.ArrayList;
import java.util.List;

public class PlayerStrategyDriver {
	public static void main(String args[]) {
		GameEngine ge = new GameEngine();
		ge.start();
	}
}