public enum HardwareState {
	operational, stuck
}
