public enum ActuatorState {
	opened, closed
}
