public enum BoilerState {
	safe, unsafe, critical
}
