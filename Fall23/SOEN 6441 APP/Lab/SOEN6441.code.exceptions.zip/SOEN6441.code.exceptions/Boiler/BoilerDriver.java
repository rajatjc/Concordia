public class BoilerDriver {
	public static void main(String[] args) {
		Boiler b = new Boiler();
		b.start();
	}
}
