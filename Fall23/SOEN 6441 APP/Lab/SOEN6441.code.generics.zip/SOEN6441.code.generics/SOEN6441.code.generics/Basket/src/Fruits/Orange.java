package Fruits;

public class Orange extends Fruit {

}
