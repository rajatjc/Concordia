package Fruits;

public class Fruit {

}
