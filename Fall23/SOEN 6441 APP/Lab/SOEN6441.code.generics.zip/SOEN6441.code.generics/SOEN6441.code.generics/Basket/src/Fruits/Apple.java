package Fruits;

public class Apple extends Fruit{

}
