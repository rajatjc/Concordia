(ns test.baz)

(def bazVar 43)

(defn bazFunc
  [x]
  (str "This is " x " in baz"))

