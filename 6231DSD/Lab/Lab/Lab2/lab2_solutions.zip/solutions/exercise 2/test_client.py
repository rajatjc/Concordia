import socket

HOST = "127.0.0.1"  # The server's hostname or IP address
PORT = 6565  # The port used by the server

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST, PORT))
    print('Connected to:', HOST, PORT)
    file_name = input('Enter your message to server: ')   # user input to block the client
    s.sendall(file_name.encode())
    file_content = bytearray()
    while True:
        packet = s.recv(1024)
        if packet[-5:] == '<EOF>'.encode():
            file_content += packet[:-5]
            break
        file_content += packet

    print(f"Got {file_name} from file server, size:", len(file_content), 'Bytes')

